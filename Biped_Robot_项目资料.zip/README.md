# Biped_Robot

双足机器人复刻项目资料。原项目为 [XRobots / YouCanBuildBiPed](https://github.com/XRobots/YouCanBuildBiPed)，原项目许可证保留在 `开源原项目/LICENSE`。

- `CAD_装配体/`：SolidWorks 装配体与零件。
- `打印文件/`：3D 打印相关 STEP、3MF 文件。
- `ESP32代码/`：PlatformIO 控制程序与独立硬件测试工程。
- `MuJoCo仿真/`：实验模型、网格、脚本与建模状态说明。
- `开源原项目/`：原作者公开文件快照及许可证。
- `项目交接记录.md`：项目背景与待核事项；其中部分状态可能过时。

## 当前状态
主程序通过编译，但实机尚未验证。仿真模型仍为实验版，材料质量、碰撞、关节限位、舵机响应和齿轮传动尚未实机标定；尚未完成可靠行走或强化学习训练，不可直接用于控制实机。详见 `MuJoCo仿真/README_建模状态.md`。

已排除 Python 虚拟环境、PlatformIO 编译缓存和编辑器配置；需要重新安装依赖。部分开发脚本及 CAD 引用包含原电脑绝对路径，换电脑后需要调整；最终姿态在 `MuJoCo仿真/biped_centered_initial_pose.xml` 的 `centered_start` 关键帧，直接加载 XML 未必自动应用该姿态。
